import React, { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet-routing-machine";
import "leaflet/dist/leaflet.css";
import AutoCompleteInput from "./AutoCompleteInput";
import TollCalculator from "./TollCalculator"; // Importăm TollCalculator
import "./App.css";

const App = () => {
  const [startCoordinates, setStartCoordinates] = useState(null);
  const [endCoordinates, setEndCoordinates] = useState(null);
  const [distance, setDistance] = useState(null);
  const [vehicleType, setVehicleType] = useState({ axles: 5, weight: 30000 });
  const [tollCost, setTollCost] = useState({ totalCost: 0, tollList: [] }); // Adăugăm obiectul cu detalii
  const [oldStartCoordinates, setOldStartCoordinates] = useState(null);
  const [oldEndCoordinates, setOldEndCoordinates] = useState(null);
  const [markers, setMarkers] = useState([]); // Folosește un state pentru a păstra marker-ele
  const [intermediateCoordinates, setIntermediateCoordinates] = useState(null);
  const mapRef = useRef(null);
  const routingControlRef = useRef(null);
  const [duration, setDuration] = useState(null);
  const [rawDistance, setRawDistance] = useState(null);
  const [rawDuration, setRawDuration] = useState(null);


  const DefaultIcon = L.icon({
    iconUrl: "https://upload.wikimedia.org/wikipedia/commons/e/ec/RedDot.svg",
    iconSize: [2, 2],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
  });
  
  L.Marker.prototype.options.icon = DefaultIcon;

  const handleVehicleTypeChange = (e) => {
    const { name, value } = e.target;
    setVehicleType((prev) => ({
      ...prev,
      [name]: Number(value),
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (startCoordinates && endCoordinates && vehicleType.axles && vehicleType.weight) {
      await getRoute(startCoordinates, intermediateCoordinates, endCoordinates, vehicleType);
    }
     else {
      alert("Te rog selectează locațiile pentru plecare și destinație!");
    }
  };

  // Funcția pentru calculul rutei:
  const getRoute = async (start, intermediate, end, vehicleType) => {
    let url = `https://router.hereapi.com/v8/routes?origin=${start.lat},${start.lng}&destination=${end.lat},${end.lng}`;
    // Adaugă punctul intermediar doar dacă există
    if (intermediate) {
      url += `&via=${intermediate.lat},${intermediate.lng}`;
    }
    url += `&return=polyline,summary,actions,instructions,tolls`
    url += `&transportMode=truck`;
    url += `&vehicle[axleCount]=5`;
    url += `&vehicle[grossWeight]=40000`;
    url += `&apikey=NtdXMcSjbr4h__U2wEhaC7i-4wTlX71ofanOwpm5E3s`;
    
    /*url += `&return=summary,tolls,truckRoadTypes,polyline`;
    url += `&spans=truckRoadTypes`;
    url += `&transportMode=truck&vehicle[axleCount]=${vehicleType.axles}`;
    url += `&exclude[countries]=CHE`;
    url += `&apikey=NtdXMcSjbr4h__U2wEhaC7i-4wTlX71ofanOwpm5E3s`;*/

    try {
      const response = await fetch(url);
      const data = await response.json();
      
      //console.log("Data received from API:", data);

      if (!data.routes || data.routes.length === 0) {
        console.error("No routes found:", data);
        return;
      }

      const route = data.routes[0];
      if (route.sections && route.sections.length > 0) {
        const section = route.sections[0];
        if (section.summary) {
          const totalDistance = section.summary.length;
          setDistance((totalDistance / 1000).toFixed(2)); // Convertim în km
        }
      }
    } catch (error) {
      console.error("Error fetching route:", error);
    }
  };


  const displayRoute = (start, intermediate, end) => {
    if (!mapRef.current) return;
  
    // Elimină controlul anterior doar dacă e atașat hărții
    if (routingControlRef.current && routingControlRef.current._map) {
      routingControlRef.current.remove();
    }
  
    const waypoints = [L.latLng(start)];
    if (intermediate) {
      waypoints.push(L.latLng(intermediate));
    }
    waypoints.push(L.latLng(end));
  
    // Resetează marker-ele înainte de a adăuga noile markere
    markers.forEach((marker) => marker.remove());
    setMarkers([]); // Resetăm lista de marker-e
  
    routingControlRef.current = L.Routing.control({
      waypoints,
      routeWhileDragging: true,
    }).addTo(mapRef.current);
  
    // Ascultă evenimentul 'routesfound' pentru recalcularea dinamică a distanței
    routingControlRef.current.on("routesfound", function (e) {
      const route = e.routes[0];
      if (route.summary) {
        // Stocăm valorile raw
        setRawDistance(route.summary.totalDistance); // în metri
        setRawDuration(route.summary.totalTime);       // în secunde
    
        // Setăm valorile formate pentru afișare
        setDistance((route.summary.totalDistance / 1000).toFixed(2));
        const hours = Math.floor(route.summary.totalTime / 3600);
        const minutes = Math.floor((route.summary.totalTime % 3600) / 60);
        setDuration(`${hours}h ${minutes}m`);
      }
    });

    addMarker(start, "start");
    if (intermediate) addMarker(intermediate, "intermediate");
    addMarker(end, "end");
  
    // Adăugăm marker pentru fiecare punct de pe traseu (start, intermediar, final)
    waypoints.forEach((point) => addMarker(point));
  };
  
  //Funcția pentru adăugarea unui marker
  const addMarker = (latLng, type = 'default') => {
    const iconUrl = type === 'start'
      ? "/green_arrow.svg"
      : type === 'end'
      ? "/red_arrow.svg"
      : "/blue_arrow.svg";  // Folosește URL-ul potrivit pentru imagine
  
    const newMarker = L.marker(latLng, {
      icon: L.icon({
        iconUrl: iconUrl,
        iconSize: [32, 32],  // Poți ajusta dimensiunile iconului
        iconAnchor: [16, 32], // Asigură-te că este corect ancorat
        popupAnchor: [0, -32],
      }),
    }).addTo(mapRef.current);
  
    // Inițializăm numărul de clickuri pentru marker
    newMarker.clickCount = 0;
  
    newMarker.on('click', (e) => {
      newMarker.clickCount += 1;
      if (newMarker.clickCount >= 3) {
        newMarker.remove();
        setMarkers((prevMarkers) => prevMarkers.filter((m) => m !== newMarker));
      }
    });
  
    setMarkers((prevMarkers) => [...prevMarkers, newMarker]);
  };
  
  
  const handleTollUpdate = (tollData) => {
    setTollCost(tollData);
    setDuration(tollData.duration); // Actualizează durata
  };
  

  useEffect(() => {
    const map = L.map("mapContainer").setView([45.0, 25.0], 6);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(map);
    mapRef.current = map;
  
    return () => {
      if (routingControlRef.current) {
        try {
          map.removeControl(routingControlRef.current);
          routingControlRef.current = null;
        } catch (error) {
          console.warn("Error while removing routing control:", error);
        }
      }
      map.remove();
      mapRef.current = null;
    };
  }, []);
  

  // useEffect(() => {
  //   if (startCoordinates && endCoordinates) {
  //     displayRoute(startCoordinates, intermediateCoordinates, endCoordinates);
  //   }
  // }, [startCoordinates, intermediateCoordinates, endCoordinates]);
  
  useEffect(() => {
    if (
      startCoordinates &&
      endCoordinates &&
      (!oldStartCoordinates ||
        !isSameCoordinates(startCoordinates, oldStartCoordinates) ||
        !isSameCoordinates(endCoordinates, oldEndCoordinates))
    ) {
      // Dacă coordonatele s-au schimbat, șterge ruta
      clearRoute();
      setOldStartCoordinates(startCoordinates); // Actualizează coordonatele vechi pentru start
      setOldEndCoordinates(endCoordinates); // Actualizează coordonatele vechi pentru end
      displayRoute(startCoordinates, intermediateCoordinates, endCoordinates); // Afișează ruta cu noile coordonate
    }
  }, [startCoordinates, endCoordinates, intermediateCoordinates]); // Dependențele sunt coordonatele de start, end și intermediar
  
  // Compară dacă coordonatele sunt aceleași
  const isSameCoordinates = (newCoordinates, oldCoordinates) => {
    if (!newCoordinates || !oldCoordinates) return false; // Asigură-te că coordonatele există
    return newCoordinates.lat === oldCoordinates.lat && newCoordinates.lng === oldCoordinates.lng;
  };
  
  const clearRoute = () => {
    if (routingControlRef.current && routingControlRef.current._map) {
      routingControlRef.current.remove(); // Elimina ruta veche
    }
  };
  
  

  return (
    <div className="App">
      <h1>Calculare Rută Camion</h1>
      <div className="container">
        <div className="sidebar">
          <form onSubmit={handleSubmit}>
            <label>
              Locație plecare:
              <AutoCompleteInput apiKey="ykLQWx4MFaivuUY1XxQzByycPVwKT4ERPsvB4a830oE" iconUrl = "/green_arrow.jpg" onSelect={setStartCoordinates} />
            </label>
            <label>
              Locație destinație:
              <AutoCompleteInput apiKey="ykLQWx4MFaivuUY1XxQzByycPVwKT4ERPsvB4a830oE" iconUrl = "/red_arrow.jpg" onSelect={setEndCoordinates} />
            </label>
            <label>
              Numar de axe:
              <input type="number" name="axles" value={vehicleType.axles} onChange={handleVehicleTypeChange} min="2" max="10" />
            </label>
            <label>
              Tonaj (kg):
              <input type="number" name="weight" value={vehicleType.weight} onChange={handleVehicleTypeChange} min="1000" max="40000" />
            </label>
            <button type="submit">Calculare rută</button>
          </form>

          {/* Afișăm detaliile taxelor */}
          <h3>Detalii Taxe Rutiere</h3>
          <p><strong>Distanta:</strong> {distance} km</p>
          <p><strong>Durata deplasării:</strong> {duration}</p>
          <p><strong>Cost Total:</strong> {tollCost.totalCost} EUR</p>
          <ul>
            {tollCost.tollList.map((toll, index) => (
              <li key={index}>
                {toll.name} - {toll.country}: {toll.cost} {toll.currency}
              </li>
            ))}
          </ul>
        </div>

        <div id="mapContainer" style={{ height: "90vh", border: "2px solid black" }} />
      </div>
      {/* Transmite coordonatele către RouteDetails */}
      <TollCalculator
        startCoordinates={startCoordinates}
        endCoordinates={endCoordinates}
        vehicleType={vehicleType}
        rawDuration={rawDuration}
        rawDistance={rawDistance}
        onTollUpdate={handleTollUpdate} // Callback pentru a actualiza costurile
      />
    </div>
  );
};

export default App;
